<?php require_once("seguridad.php");?>
<!DOCTYPE html>
<html lang="es">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="logo.png">

    <title>Inicio</title>

    <link href="css/bootstrap.css" rel="stylesheet">
    <script type="text/javascript" src="jquery-1.4.2.min.js"></script>
    <script type="text/javascript" src="jquery.alerts.js"></script>
    <link href="jquery.alerts.css" rel="stylesheet" type="text/css" />
	
<style>
   .letra {
    font-weight: bold;
    }
</style>
<style>
table {
    border-collapse: collapse;
    width: 100%;
}

th, td {
    text-align: left;
    padding: 8px;
}

tr:nth-child(even){background-color: #f2f2f2}

th {
    background-color: #00CC07;
    color: white;
}
</style>

<script>
$(document).ready(function(){
  $('.dropdown-submenu a.test').on("click", function(e){
    $(this).next('ul').toggle();
    e.stopPropagation();
    e.preventDefault();
  });
});
</script>
<script type="text/javascript"> 
$(document).ready(function(){
	$('#boton_jalert').click(function() {
		jAlert("Mensaje de Alerta", "SiDenTux Ver. 1.0 Rev. 2.2");
	});
	$("#boton_promp").click( function() {
					jPrompt('Teclea el folio:', '', 'SiDenTux Ver. 1.0 Rev. 2.2', function(r) {
						var jfolio = r;
						if (r)  
                        {
						location.href='buscarfolio.php?sendfolio='+jfolio; 
						}
						else
						{
						jAlert("No se aceptan espacios en Blanco", "SiDenTux Ver. 1.0 Rev. 2.2");	
						}
							
					});
				});
	$('#boton_jconfirm').click(function() {
		jConfirm("¿Seguro(a) de realizar esta operación?", "SiDenTux Ver. 1.0 Rev. 2.2", function(r) {
			if(r) {
				mostrar2();
			} else {
				jAlert("Cancelar operación", "SiDenTux Ver. 1.0 Rev. 2.2");
			}
		});
	});
});
</script>
  </head>
  <body>

    <div class="container">

     <nav class="navbar navbar-default letra">
        <div class="container-fluid">
          <div class="navbar-header">
            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
            </button>
            <a class="navbar-brand" ><?php echo $_SESSION['usuarioactual']?></a>
          </div>
          <div id="navbar" class="navbar-collapse collapse">
            <ul class="nav navbar-nav">
			      <li><a href="salir.php">Cerrar Sesión</a></li>
            </ul>
            <ul class="nav navbar-nav navbar-right" >
             </ul>
          </div>
        </div>
      </nav>
    <div class="letra">
   	<div align='center'>  
	<center><h3>Inicio de </h3></center>


    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
    <script src="bootstrap.min.js"></script>

  </body>
</html>
