<?php require_once("seguridad.php");?>
<!DOCTYPE html>
<html lang="es">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="logo.png">

    <title>Inicio</title>

    <link href="css/bootstrap.css" rel="stylesheet">
    <script type="text/javascript" src="jquery-1.4.2.min.js"></script>
    <script type="text/javascript" src="jquery.alerts.js"></script>
    <link href="jquery.alerts.css" rel="stylesheet" type="text/css" />
	
<style>
   .letra {
    font-weight: bold;
    }
</style>
<style>
table {
    border-collapse: collapse;
    width: 100%;
}

th, td {
    text-align: left;
    padding: 8px;
}

tr:nth-child(even){background-color: #f2f2f2}

th {
    background-color: #00CC07;
    color: white;
}
</style>

<script>
$(document).ready(function(){
  $('.dropdown-submenu a.test').on("click", function(e){
    $(this).next('ul').toggle();
    e.stopPropagation();
    e.preventDefault();
  });
});
</script>
<script type="text/javascript"> 
$(document).ready(function(){
	$('#boton_jalert').click(function() {
		jAlert("Mensaje de Alerta", "SiDenTux Ver. 1.0 Rev. 2.2");
	});
	$("#boton_promp").click( function() {
					jPrompt('Teclea el folio:', '', 'SiDenTux Ver. 1.0 Rev. 2.2', function(r) {
						var jfolio = r;
						if (r)  
                        {
						location.href='buscarfolio.php?sendfolio='+jfolio; 
						}
						else
						{
						jAlert("No se aceptan espacios en Blanco", "SiDenTux Ver. 1.0 Rev. 2.2");	
						}
							
					});
				});
	$('#boton_jconfirm').click(function() {
		jConfirm("¿Seguro(a) de realizar esta operación?", "SiDenTux Ver. 1.0 Rev. 2.2", function(r) {
			if(r) {
				mostrar2();
			} else {
				jAlert("Cancelar operación", "SiDenTux Ver. 1.0 Rev. 2.2");
			}
		});
	});
});
</script>
  </head>
  <body>

    <div class="container">

     <nav class="navbar navbar-default letra">
        <div class="container-fluid">
          <div class="navbar-header">
            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
            </button>
            <a class="navbar-brand" ><?php echo $_SESSION['usuarioactual']?></a>
          </div>
          <div id="navbar" class="navbar-collapse collapse">
            <ul class="nav navbar-nav">
			<li class="active"><a href="#">Folios</a></li>
			   <li class="dropdown">
                <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Herramientas<span class="caret"></span></a>
                <ul class="dropdown-menu">
                  <li><a href="#" id="boton_promp">Buscar Folios</a></li>
				  <li class="dropdown-submenu">
                  <a class="test" tabindex="-1" href="#">Reportes<span class="caret"></span></a>
                  <ul class="dropdown-menu">
                  <li><a tabindex="-1" href="#">Por Folio</a></li>
                  <li><a tabindex="-1" href="#">Global</a></li>
                  </ul>
                  </li>
				  </ul>                
                  </li>
			      <li><a href="salir.php">Cerrar Sesión</a></li>
            </ul>
            <ul class="nav navbar-nav navbar-right" >
             </ul>
          </div>
        </div>
      </nav>
    <div class="letra">
   	<div align='center'>  
	<center><h3>Inicio de </h3></center>
	<table>  
	 <tr>   
	  <td>Imprimir</td>
      <td>Folio</td>    
      <td>Móvil</td>   
	  <td>Nombre</td>
	  <td>Correo</td>
	  <td>Mensaje</td>
	  <td>Fecha/Hora</td>
    </tr>  
	<?php
       require_once("conexion.php"); 
       $sql = "SELECT * FROM denuncias";
	   $resultado = mysqli_query($conecta,$sql);
	   $total_registros = mysqli_num_rows($resultado);
	   
	   //Si hay registros
     if ($total_registros > 0) {
	  //Limito la busqueda
	  $TAMANO_PAGINA = 8;
        $pagina = false;
	  //examino la pagina a mostrar y el inicio del registro a mostrar
        if (isset($_GET["pagina"]))
            $pagina = $_GET["pagina"];
       
	   if (!$pagina) {
		$inicio = 0;
		$pagina = 1;
	}
	else {
		$inicio = ($pagina - 1) * $TAMANO_PAGINA;
	}
	//calculo el total de paginas
	$total_paginas = ceil($total_registros / $TAMANO_PAGINA);
	$consulta = "SELECT * FROM denuncias ORDER BY folio ASC LIMIT ".$inicio."," . $TAMANO_PAGINA;
	$rs = mysqli_query($conecta, $consulta);
	
	if ($total_paginas > 1) {
		if ($pagina != 1)
			echo '<a href="'.$url.'?pagina='.($pagina-1).'"><img src="images/izq.gif" border="0">&nbsp;&nbsp;</a>';
		for ($i=1;$i<=$total_paginas;$i++) {
			if ($pagina == $i)
				//si muestro el índice de la página actual, no coloco enlace
				echo $pagina;
			else
				//si el indice no corresponde con la página mostrada actualmente,
				//coloco el enlace para ir a esa página
				echo '  <a href="'.$url.'?pagina='.$i.'">'.$i.'</a>  ';
		}
		if ($pagina != $total_paginas)
			echo '<a href="'.$url.'?pagina='.($pagina+1).'">&nbsp;&nbsp;<img src="images/der.gif" border="0"></a>';
	}
	echo '</p>';
}
       while ($dato=mysqli_fetch_array($rs)) {
       echo "<tr>";
       echo "<td><a href=detalle.php?var=$dato[1] target='_blank'><img src='images/impresora.png'></td>";
       echo "<td>$dato[1]</td>";  
	   echo "<td>$dato[2]</td>";
	   echo "<td>$dato[3]</td>";
	   echo "<td>$dato[4]</td>";
	   echo "<td>$dato[5]</td>";
	   echo "<td>$dato[7]</td>";
	   echo "</tr>";	   
	   }
	  mysqli_close($conecta);    
 ?>
</table>   
</div>
<?php echo '<h4>Página  ' .$pagina. '  de  ' .$total_paginas.'  páginas.</h4>';?>
</div> <!-- /container -->

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
    <script src="bootstrap.min.js"></script>

  </body>
</html>
